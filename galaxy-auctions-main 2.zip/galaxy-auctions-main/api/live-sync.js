const SUPABASE_URL=String(process.env.SUPABASE_URL||'https://exfxcgiuotraszeqefha.supabase.co').replace(/\/$/,'');
const key=()=>process.env.SUPABASE_SERVICE_ROLE_KEY;
async function sfetch(path,opts={}){const k=key();if(!k)throw new Error('SUPABASE_SERVICE_ROLE_KEY is not configured');return fetch(SUPABASE_URL+'/rest/v1/'+path,{...opts,headers:{apikey:k,Authorization:`Bearer ${k}`,'Content-Type':'application/json',...(opts.headers||{})}})}
const {nextAuctionTime}=require('../auction-schedule');
const LOT_SECONDS=15,BONUS_SECONDS=15,SOLD_SECONDS=2;
// 18:00 Dubai = 14:00 UTC. First scheduled session: 9 October 2026.
// After a completed session enters waiting, the next session is the following day at 18:00 Dubai.
const FIRST_AUCTION_MS=Date.parse('2026-10-09T14:00:00.000Z');
const DAY_MS=86400000;
function scheduledStart(state,now){
 if(state.status!=='waiting')return nextAuctionTime(now);
 const waitingSince=Date.parse(state.phase_started_at||state.updated_at||now);
 if(!Number.isFinite(waitingSince)||waitingSince<FIRST_AUCTION_MS)return new Date(FIRST_AUCTION_MS);
 const nextIndex=Math.floor((waitingSince-FIRST_AUCTION_MS)/DAY_MS)+1;
 return new Date(FIRST_AUCTION_MS+nextIndex*DAY_MS);
}
async function activeLots(){const r=await sfetch('auction_lots?status=in.(upcoming,live)&select=id,lot_number,starting_bid,status,description,sort_order&order=sort_order.asc,lot_number.asc');if(!r.ok)return[];return await r.json()||[]}
function orderedQueue(rows,state){const current=Number(state?.lot_id||0);if(state?.status!=='live'||!current)return rows.slice();const selected=rows.find(x=>Number(x.lot_number)===current);return selected?[selected,...rows.filter(x=>Number(x.lot_number)!==current)]:rows.slice();}
async function bidderCountries(bids){
 const ids=[...new Set((bids||[]).map(b=>String(b.user_id||'')).filter(Boolean))];
 if(!ids.length)return bids||[];
 const safe=ids.filter(id=>/^\d+$/.test(id)).join(',');
 if(!safe)return bids||[];
 const r=await sfetch(`auction_users?telegram_id=in.(${safe})&select=telegram_id,phone_country,country`);
 const users=r.ok?await r.json():[],map=new Map((users||[]).map(u=>[String(u.telegram_id),String(u.phone_country||u.country||'').slice(0,2).toUpperCase()]));
 return (bids||[]).map(b=>({...b,country:map.get(String(b.user_id))||((String(b.country||'').toUpperCase()==='PB')?'':String(b.country||'').slice(0,2).toUpperCase())}));
}
async function setLotStatus(lotNumber,status,now){return sfetch(`auction_lots?lot_number=eq.${Number(lotNumber)}`,{method:'PATCH',body:JSON.stringify({status,updated_at:now})})}
async function proxyStart(lot,now){const lotId=Number(lot.lot_number),base=Number(lot.starting_bid||0);let r=await sfetch(`auction_bids?lot_id=eq.${lotId}&country=eq.PB&select=id,user_id,username,amount&order=id.desc`),rows=r.ok?await r.json():[];const by=new Map();for(const b of rows||[]){const k=String(b.user_id);if(!by.has(k))by.set(k,b)}const bids=[...by.values()].map(b=>({...b,amount:Number(b.amount||0)})).sort((a,b)=>b.amount-a.amount||Number(b.id)-Number(a.id)),leader=bids[0]||null,second=bids[1]||null,current=leader?Math.max(base,leader.amount):base;if(leader){await sfetch('auction_bids',{method:'POST',body:JSON.stringify({lot_id:lotId,user_id:String(leader.user_id),username:leader.username||'Bidder',amount:current,country:''})})}return current}
module.exports=async(req,res)=>{if(req.method!=='GET'&&req.method!=='POST')return res.status(405).json({error:'Method not allowed'});try{
 let r=await sfetch('auction_state?id=eq.1&select=*');let state=(await r.json())?.[0];if(!r.ok||!state)throw new Error('Auction state unavailable');
 const nowMs=Date.now(),nowIso=new Date(nowMs).toISOString(),started=Date.parse(state.phase_started_at||state.updated_at||nowIso),age=Math.max(0,(nowMs-started)/1000),phase=String(state.phase||'red').toLowerCase();
 let all=await activeLots(),queue=all.slice(0,200),startAt=scheduledStart(state,nowIso),canStart=state.status==='waiting'&&nowMs>=startAt.getTime();
 const currentNo=Number(state.lot_id||0), currentSelected=queue.find(x=>Number(x.lot_number)===currentNo);let patch=null;
 // The full upcoming queue is available for preview, then starts on the next hour.
 if(state.status==='waiting'&&!canStart){const first=queue[0];if(first&&currentNo!==Number(first.lot_number))patch={lot_id:Number(first.lot_number),current_bid:await proxyStart(first,nowIso),phase:'wait',status:'waiting'};}
 else if(!currentSelected){all=await activeLots();queue=all.slice(0,200);const first=queue[0];if(first&&canStart){await setLotStatus(first.lot_number,'live',nowIso);patch={lot_id:Number(first.lot_number),current_bid:await proxyStart(first,nowIso),phase:'red',phase_started_at:nowIso,status:'live'};}else if(state.status!=='waiting')patch={phase:'wait',phase_started_at:nowIso,status:'waiting'};}
 else if(state.status==='waiting'&&canStart){await setLotStatus(currentSelected.lot_number,'live',nowIso);patch={lot_id:Number(currentSelected.lot_number),current_bid:await proxyStart(currentSelected,nowIso),phase:'red',phase_started_at:nowIso,status:'live'};}
 else if(state.status==='live'&&phase==='sold'&&age>=SOLD_SECONDS){let br=await sfetch(`auction_bids?lot_id=eq.${currentNo}&select=id&limit=1`),hasBid=br.ok&&((await br.json())||[]).length>0;if(hasBid){await setLotStatus(currentNo,'pending',nowIso);}else{await setLotStatus(currentNo,'draft',nowIso);}all=await activeLots();queue=all.filter(x=>Number(x.lot_number)!==currentNo).slice(0,200);const next=queue[0];if(next){await setLotStatus(next.lot_number,'live',nowIso);patch={lot_id:Number(next.lot_number),current_bid:await proxyStart(next,nowIso),phase:'red',phase_started_at:nowIso,status:'live'};}else patch={phase:'wait',phase_started_at:nowIso,status:'waiting'};}
 else if(state.status==='live'&&!['bonus','green','sold','wait'].includes(phase)&&age>=LOT_SECONDS)patch={phase:'bonus',phase_started_at:nowIso,status:'live'};
 else if(state.status==='live'&&['bonus','green'].includes(phase)&&age>=BONUS_SECONDS)patch={phase:'sold',phase_started_at:nowIso,status:'live'};
 if(patch){const expected=encodeURIComponent(state.phase_started_at||''),q=`auction_state?id=eq.1&phase_started_at=eq.${expected}&phase=eq.${encodeURIComponent(state.phase||'')}`;r=await sfetch(q,{method:'PATCH',headers:{Prefer:'return=representation'},body:JSON.stringify({...patch,updated_at:nowIso})});const changed=await r.json();if(r.ok&&changed?.length)state=changed[0];else{r=await sfetch('auction_state?id=eq.1&select=*');state=(await r.json())?.[0]||state;}}
 const lotId=Number(state.lot_id||0);r=await sfetch(`auction_bids?lot_id=eq.${lotId}&country=neq.PB&select=user_id,username,country,amount,created_at,id&order=id.desc&limit=20`);let bids=await r.json();if(!Array.isArray(bids))bids=[];const statePrice=Number(state.current_bid||0);const exact=bids.find(b=>Number(b.amount)===statePrice);if(exact)bids=[exact,...bids.filter(b=>b!==exact)].slice(0,4);else bids=bids.slice(0,4);if(state.status==='waiting'&&lotId){const pr=await sfetch(`auction_bids?lot_id=eq.${lotId}&country=eq.PB&select=id,user_id,username,amount&order=id.desc`),rows=pr.ok?await pr.json():[],latest=new Map();for(const pb of rows||[]){const k=String(pb.user_id);if(!latest.has(k))latest.set(k,pb)}const proxy=[...latest.values()].map(x=>({...x,amount:Number(x.amount||0)})).sort((a,b)=>b.amount-a.amount||Number(b.id)-Number(a.id)),leader=proxy[0]||null,second=proxy[1]||null;if(leader){const base=Number((queue.find(x=>Number(x.lot_number)===lotId)||{}).starting_bid||state.current_bid||0),visible=Math.max(base,leader.amount);state={...state,current_bid:visible};bids=[{user_id:leader.user_id,username:leader.username,country:'',amount:visible,id:leader.id},...bids.filter(x=>String(x.user_id)!==String(leader.user_id))].slice(0,4)}}
 bids=await bidderCountries(bids);
 let lot=null;if(lotId){const lr=await sfetch(`auction_lots?lot_number=eq.${lotId}&select=*,auction_lot_images(id,image_url,is_primary,sort_order)`);const rows=await lr.json();if(lr.ok&&rows?.[0]){lot=rows[0];const images=(lot.auction_lot_images||[]).sort((a,b)=>(a.sort_order||0)-(b.sort_order||0));delete lot.auction_lot_images;lot.images=images;lot.primary_image=(images.find(x=>x.is_primary)||images[0])?.image_url||null;}}
 const sr=await sfetch('auction_lots?select=lot_number,status');const statusRows=sr.ok?await sr.json():[];const lotStatuses=Object.fromEntries((statusRows||[]).map(x=>[String(x.lot_number),x.status]));
 all=await activeLots();queue=orderedQueue(all,state).slice(0,200);startAt=state.status==='waiting'?scheduledStart(state,nowIso):new Date(new Date(state.phase_started_at||nowIso).setUTCMinutes(0,0,0));
 res.setHeader('Cache-Control','no-store, max-age=0');res.status(200).json({serverNow:nowIso,todayQueue:queue.map(x=>Number(x.lot_number)),startAt:startAt.toISOString(),canBid:state.status==='live',state,bids:Array.isArray(bids)?bids:[],lot,lotStatuses});
 }catch(e){res.status(500).json({error:e.message});}}
module.exports.orderedQueue=orderedQueue;
